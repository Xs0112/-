package com.study.shop.util;

import java.sql.*;

/**
 * 链接数据库的工具类
 */
public class JDBCUtil {
    //声明连接数据库使用的对象
    //数据库链接地址
    private static final String url = "jdbc:mysql://localhost:3306/shop?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=UTC";
    //数据库链接用户名
    private static final String user = "root";
    //自己的数据库密码
    private static final String password = "561665";
    //连接数据库驱动
    private static String driver = "com.mysql.cj.jdbc.Driver";

    //注册加载驱动
    static{
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    //获取数据库连接
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(url,user,password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //关闭资源
    public static void closeAll(Connection con, PreparedStatement pst, ResultSet res) {
        try {
            if(con != null) {
                con.close();
            }
            if(pst != null) {
                pst.close();
            }
            if(res != null) {
                res.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
